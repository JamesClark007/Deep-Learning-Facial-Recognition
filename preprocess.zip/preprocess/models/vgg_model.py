from models.model import Model

class VGGModel(Model):
    def _define_model(self, input_shape, categories_count):
        # Your code goes here

        # self.model = <model definition>
        pass
    
    def _compile_model(self):
        # Your code goes here

        # self.model.compile(<configuration properties>)
        pass
