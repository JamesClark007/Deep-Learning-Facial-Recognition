from models.model import Model
from tensorflow.keras import layers
from tensorflow.keras import models
from tensorflow.keras import optimizers
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense

class BasicModel(Model):
    def _define_model(self, input_shape, categories_count):
        # Your code goes here
        self.model = Sequential([
            Conv2D(32, (3, 3), activation='relu', input_shape=self.input_shape),
            MaxPooling2D((2, 2)),
            Conv2D(64, (3, 3), activation='relu'),
            MaxPooling2D((2, 2)),
            Flatten(),
            Dense(128, activation='relu'),
            Dense(64, activation='relu'),
            Dense(self.num_classes, activation='softmax')
        ])

        return model

        # self.model = <model definition>
    
    def _compile_model(self):
        # Your code goes here
        self.model.compile(
            optimizer = RMSprop(learning_rate = 0.001),
            loss = 'categorical_crossentropy',
            metrics = ['accuracy']
        )
        history = self.model.fit(
            x = train_dataset,
            epochs = epochs,
            Verbose = "auto",
            validation_data = validation_dataset,
        )
        model.save('model.keras')

        # self.model.compile(<configuration properties>)